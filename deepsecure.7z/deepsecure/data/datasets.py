# file: deepsecure/data/datasets.py

from pathlib import Path
from typing import Callable, Optional

from PIL import Image
import torch
from torch.utils.data import Dataset
import torchvision.transforms as T


class PairedUnderwaterDataset(Dataset):
    """
    Handles datasets like EUVP, UFO-120 where we have:
        - degraded / raw images
        - corresponding ground truth
    """

    def __init__(
        self,
        raw_dir: str,
        gt_dir: str,
        transform: Optional[Callable] = None,
    ):
        self.raw_dir = Path(raw_dir)
        self.gt_dir = Path(gt_dir)
        self.raw_files = sorted(list(self.raw_dir.glob("*.jpg")) + list(self.raw_dir.glob("*.png")))
        self.transform = transform or T.Compose([
            T.Resize((256, 256)),
            T.ToTensor()
        ])

    def __len__(self):
        return len(self.raw_files)

    def __getitem__(self, idx):
        raw_path = self.raw_files[idx]
        gt_path = self.gt_dir / raw_path.name  # assumes same filenames

        raw_img = Image.open(raw_path).convert("RGB")
        gt_img = Image.open(gt_path).convert("RGB")

        raw_t = self.transform(raw_img)
        gt_t = self.transform(gt_img)

        return {
            "raw": raw_t,
            "gt": gt_t,
            "name": raw_path.name
        }
