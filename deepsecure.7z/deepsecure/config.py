# file: deepsecure/config.py

import torch

DEVICE = "cuda" if torch.cuda.is_available() else "cpu"

# UIE model names
UIE_FUNIE = "funie_gan"
UIE_AURIE = "aurie"
UIE_CORAL = "coral_net"

# Simple scheduler thresholds (you can tune/replace)
LOW_LIGHT_THRESHOLD = 0.3  # for illumination-based decisions
SHALLOW_REEF_LABEL = "shallow_reef"

# Adversarial settings
FGSM_EPS = 4.0 / 255.0  # default epsilon

# Encryption params (logistic map)
LOGISTIC_R = 3.99
LOGISTIC_X0 = 0.54321

# Blockchain / logging
BLOCKCHAIN_RPC_URL = "https://rpc.your-testnet.example"
CONTRACT_ADDRESS = "0x0000000000000000000000000000000000000000"  # replace
CONTRACT_ABI_PATH = "contract_abi.json"  # path to ABI json

FRAME_TIME_BUDGET_MS = 250.0
