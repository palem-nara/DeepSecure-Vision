# file: deepsecure/pipeline/processor.py

import io
import time
from typing import Dict, Any

import torch

from deepsecure.config import DEVICE, FRAME_TIME_BUDGET_MS
from deepsecure.models.uie_scheduler import UIEPipeline, SceneMetadata
from deepsecure.models.vad import VADConvNet
from deepsecure.security.encryption import encrypt_frame
from deepsecure.security.blockchain_logger import FrameLogger


class DeepSecureVisionProcessor:
    """
    Implements the end-to-end flow for a single frame:
        1) UIE enhancement (F_UIE)
        2) VAD inspection
        3) Chaotic encryption
        4) Blockchain logging
    """

    def __init__(self, anomaly_threshold: float = 0.5):
        self.device = DEVICE
        self.uie = UIEPipeline(device=self.device)
        self.vad = VADConvNet().to(self.device)
        self.logger = FrameLogger()
        self.anomaly_threshold = anomaly_threshold

    def process_frame(
        self,
        frame_tensor: torch.Tensor,
        meta: SceneMetadata,
        tx_params: Dict[str, Any]
    ) -> Dict[str, Any]:
        """
        frame_tensor: [3,H,W] in [0,1]
        Returns dict with:
            - enhanced
            - is_anomalous
            - encrypted
            - tx_hash (or None if skipped)
            - processing_time_ms
        """
        t0 = time.time()

        frame_batch = frame_tensor.unsqueeze(0).to(self.device)

        # 1) Enhancement
        enhanced = self.uie.enhance(frame_batch, meta)

        # 2) VAD inspection
        anomaly_prob = self.vad.anomaly_score(enhanced)
        is_anomalous = anomaly_prob.item() > self.anomaly_threshold

        if is_anomalous:
            processing_time_ms = (time.time() - t0) * 1000.0
            return {
                "enhanced": enhanced.cpu(),
                "is_anomalous": True,
                "encrypted": None,
                "tx_hash": None,
                "processing_time_ms": processing_time_ms,
            }

        # 3) Encryption
        encrypted = encrypt_frame(enhanced)

        # 4) Logging
        # Convert enhanced image to bytes (e.g., PNG) for hashing/logging
        enhanced_np = (enhanced.squeeze(0).cpu().clamp(0, 1).numpy() * 255).astype("uint8")
        from PIL import Image
        img = Image.fromarray(enhanced_np.transpose(1, 2, 0))
        buf = io.BytesIO()
        img.save(buf, format="PNG")
        enhanced_bytes = buf.getvalue()

        tx_hash = self.logger.log_frame(enhanced_bytes, tx_params)

        processing_time_ms = (time.time() - t0) * 1000.0

        return {
            "enhanced": enhanced.cpu(),
            "is_anomalous": False,
            "encrypted": encrypted.cpu(),
            "tx_hash": tx_hash,
            "processing_time_ms": processing_time_ms,
            "within_budget": processing_time_ms <= FRAME_TIME_BUDGET_MS,
        }
