# file: scripts/run_pipeline.py

from pathlib import Path

from PIL import Image
import torchvision.transforms as T
import torch

from deepsecure.models.uie_scheduler import SceneMetadata
from deepsecure.pipeline.processor import DeepSecureVisionProcessor


def load_frame(path: str) -> torch.Tensor:
    img = Image.open(path).convert("RGB")
    transform = T.Compose([
        T.Resize((256, 256)),
        T.ToTensor()
    ])
    return transform(img)


def main():
    frame_path = "example_underwater.jpg"
    frame = load_frame(frame_path)

    meta = SceneMetadata(
        avg_illumination=float(frame.mean().item()),
        device_type="edge",
        target_profile="shallow_reef"
    )

    # Minimal tx_params (you must fill in real values)
    tx_params = {
        "from": "0xYourAddress",
        "gas": 300000,
        "nonce": 0,  # update with real nonce
        "private_key": "0xYourPrivateKey",  # NEVER hardcode in real code!
    }

    processor = DeepSecureVisionProcessor(anomaly_threshold=0.5)

    out = processor.process_frame(frame, meta, tx_params)

    print("Anomalous?:", out["is_anomalous"])
    print("Processing time (ms):", out["processing_time_ms"])
    print("Within 250ms budget?:", out.get("within_budget", None))
    print("Blockchain tx hash:", out["tx_hash"])


if __name__ == "__main__":
    main()
