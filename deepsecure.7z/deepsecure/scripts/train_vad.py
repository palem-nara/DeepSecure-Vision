# file: scripts/train_vad.py

import torch
import torch.optim as optim
from torch.utils.data import DataLoader

from deepsecure.config import DEVICE
from deepsecure.data.datasets import PairedUnderwaterDataset
from deepsecure.models.vad import VADConvNet
from deepsecure.security.adversarial import fgsm_attack


def main():
    dataset = PairedUnderwaterDataset(
        raw_dir="data/EUVP/raw",
        gt_dir="data/EUVP/gt"
    )
    loader = DataLoader(dataset, batch_size=8, shuffle=True, num_workers=4)

    vad = VADConvNet().to(DEVICE)
    optimizer = optim.Adam(vad.parameters(), lr=1e-4)
    criterion = torch.nn.BCEWithLogitsLoss()

    for epoch in range(5):
        for batch in loader:
            raw = batch["raw"].to(DEVICE)

            # Create fake "clean" and "adversarial" examples
            labels_clean = torch.zeros(raw.size(0), 1, device=DEVICE)
            labels_adv = torch.ones(raw.size(0), 1, device=DEVICE)

            # For demonstration, attack the VAD itself
            adv_imgs = fgsm_attack(vad, raw, labels_adv.squeeze().long())

            inputs = torch.cat([raw, adv_imgs], dim=0)
            labels = torch.cat([labels_clean, labels_adv], dim=0)

            optimizer.zero_grad()
            logits = vad(inputs)
            loss = criterion(logits, labels)
            loss.backward()
            optimizer.step()

        print(f"Epoch {epoch+1}: loss = {loss.item():.4f}")


if __name__ == "__main__":
    main()
