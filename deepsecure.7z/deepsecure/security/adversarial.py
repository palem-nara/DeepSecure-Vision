# file: deepsecure/security/adversarial.py

from typing import Tuple

import torch
from torch import nn

from deepsecure.config import FGSM_EPS


def fgsm_attack(
    model: nn.Module,
    images: torch.Tensor,
    labels: torch.Tensor,
    epsilon: float = FGSM_EPS
) -> torch.Tensor:
    """
    Implements: I_adv = I_raw + ε * sign(∇_I L(I_raw, y))
    images: [B, 3, H, W] in [0,1]
    labels: [B] or one-hot, depending on loss
    """

    images = images.clone().detach().requires_grad_(True)
    model.eval()
    criterion = nn.CrossEntropyLoss()

    outputs = model(images)
    loss = criterion(outputs, labels)
    loss.backward()

    grad_sign = images.grad.sign()
    adv_images = images + epsilon * grad_sign
    adv_images = torch.clamp(adv_images, 0.0, 1.0)
    return adv_images.detach()


def insert_trigger_patch(
    images: torch.Tensor,
    trigger_patch: torch.Tensor,
    top_left: Tuple[int, int] = (0, 0)
) -> torch.Tensor:
    """
    Implements:
        I_spoof(x,y) = P_trigger(x,y), if (x,y) in R_patch
                     = I_raw(x,y),     otherwise
    images: [B, 3, H, W]
    trigger_patch: [3, h, w]
    """

    b, c, h, w = images.shape
    _, ph, pw = trigger_patch.shape
    y0, x0 = top_left

    out = images.clone()
    y1, x1 = min(y0 + ph, h), min(x0 + pw, w)

    patch_h = y1 - y0
    patch_w = x1 - x0

    if patch_h <= 0 or patch_w <= 0:
        return out

    out[:, :, y0:y1, x0:x1] = trigger_patch[:, :patch_h, :patch_w]
    return out
