# file: deepsecure/security/encryption.py

import numpy as np
import torch

from deepsecure.config import LOGISTIC_R, LOGISTIC_X0


def logistic_map_sequence(n: int, x0: float = LOGISTIC_X0, r: float = LOGISTIC_R):
    """
    x_{n+1} = r * x_n * (1 - x_n), x_0 ∈ (0,1), r ∈ [3.57, 4]
    Generates n values in (0,1).
    """
    x = x0
    seq = np.empty(n, dtype=np.float32)
    for i in range(n):
        x = r * x * (1.0 - x)
        seq[i] = x
    return seq


def encrypt_frame(enhanced: torch.Tensor) -> torch.Tensor:
    """
    E(i,j) = I_enh(i,j) XOR C(i,j)
    - enhanced: [B, 3, H, W] in [0,1]
    - returns encrypted frames as uint8-like tensor in [0,255] (float).
    """

    b, c, h, w = enhanced.shape
    n = b * c * h * w

    # Convert to uint8
    img_np = (enhanced.cpu().numpy() * 255.0).astype(np.uint8)

    # Chaotic sequence -> uint8
    seq = logistic_map_sequence(n)
    seq_uint8 = (seq * 255.0).astype(np.uint8).reshape(b, c, h, w)

    encrypted = np.bitwise_xor(img_np, seq_uint8)
    encrypted_torch = torch.from_numpy(encrypted).float()  # keep as float [0,255]
    return encrypted_torch


def decrypt_frame(encrypted: torch.Tensor) -> torch.Tensor:
    """
    Decryption is identical to encryption for XOR stream ciphers.
    """
    b, c, h, w = encrypted.shape
    n = b * c * h * w
    enc_np = encrypted.cpu().numpy().astype(np.uint8)

    seq = logistic_map_sequence(n)
    seq_uint8 = (seq * 255.0).astype(np.uint8).reshape(b, c, h, w)

    decrypted = np.bitwise_xor(enc_np, seq_uint8)
    decrypted = torch.from_numpy(decrypted).float() / 255.0  # back to [0,1]
    return decrypted
