# file: deepsecure/security/blockchain_logger.py

import json
import hashlib
from pathlib import Path
from typing import Any, Dict

from web3 import Web3

from deepsecure.config import BLOCKCHAIN_RPC_URL, CONTRACT_ADDRESS, CONTRACT_ABI_PATH


class FrameLogger:
    """
    Computes:
        FrameHash = SHA256(I_enh)
    and stores hash on an Ethereum testnet smart contract.
    """

    def __init__(self):
        self.web3 = Web3(Web3.HTTPProvider(BLOCKCHAIN_RPC_URL))
        abi = json.loads(Path(CONTRACT_ABI_PATH).read_text())
        self.contract = self.web3.eth.contract(address=CONTRACT_ADDRESS, abi=abi)

    @staticmethod
    def frame_hash(enhanced_bytes: bytes) -> str:
        h = hashlib.sha256()
        h.update(enhanced_bytes)
        return h.hexdigest()

    def log_frame(self, enhanced_bytes: bytes, tx_params: Dict[str, Any]) -> str:
        """
        tx_params: dict with 'from', 'gas', etc.
        returns tx hash hex
        """
        fh = self.frame_hash(enhanced_bytes)
        tx = self.contract.functions.logFrameHash(fh).build_transaction(tx_params)
        signed = self.web3.eth.account.sign_transaction(tx, private_key=tx_params["private_key"])
        tx_hash = self.web3.eth.send_raw_transaction(signed.rawTransaction)
        return self.web3.to_hex(tx_hash)
