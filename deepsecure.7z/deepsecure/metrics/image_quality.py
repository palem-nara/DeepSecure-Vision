# file: deepsecure/metrics/image_quality.py

from typing import Tuple

import torch
import torch.nn.functional as F


def psnr(gt: torch.Tensor, pred: torch.Tensor, max_val: float = 1.0) -> float:
    """
    PSNR between ground truth and prediction.
    gt, pred: [B,3,H,W] in [0,1]
    """
    mse = F.mse_loss(pred, gt)
    if mse == 0:
        return 99.0
    return float(10.0 * torch.log10(max_val ** 2 / mse))


def ssim(
    gt: torch.Tensor,
    pred: torch.Tensor,
    C1: float = 0.01 ** 2,
    C2: float = 0.03 ** 2
) -> float:
    """
    Simplified SSIM over whole image (not windowed).
    Uses:
      SSIM = ((2 μ_gt μ_enh + C1)(2 σ_gt,enh + C2)) /
             ((μ_gt^2 + μ_enh^2 + C1)(σ_gt^2 + σ_enh^2 + C2))
    """
    gt_mean = gt.mean()
    pr_mean = pred.mean()

    gt_var = gt.var(unbiased=False)
    pr_var = pred.var(unbiased=False)
    covariance = ((gt - gt_mean) * (pred - pr_mean)).mean()

    numerator = (2 * gt_mean * pr_mean + C1) * (2 * covariance + C2)
    denominator = (gt_mean ** 2 + pr_mean ** 2 + C1) * (gt_var + pr_var + C2)

    return float((numerator / denominator).item())


def uciqe_stub(image: torch.Tensor) -> float:
    """
    Placeholder for UCIQE.
    Implement full metric if required.
    """
    # TODO: Implement real UCIQE; here we just use contrast proxy.
    return float(image.std().item())


def uiqm_stub(image: torch.Tensor) -> float:
    """
    Placeholder for UIQM.
    Implement full metric if required.
    """
    # TODO: Implement real UIQM; here we just use mean brightness proxy.
    return float(image.mean().item())
