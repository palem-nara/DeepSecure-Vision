# file: deepsecure/models/vad.py

import torch
import torch.nn as nn
import torch.nn.functional as F


class VADConvNet(nn.Module):
    """
    Visual Anomaly Detection module:
    - Input: enhanced image [B, 3, H, W]
    - Output: anomaly logit (or probability) [B, 1]
    Focuses on textures/gradients and can be trained with
    adversarial vs clean labels.
    """

    def __init__(self):
        super().__init__()
        self.conv1 = nn.Conv2d(3, 32, 3, padding=1)
        self.bn1 = nn.BatchNorm2d(32)
        self.conv2 = nn.Conv2d(32, 64, 3, padding=1)
        self.bn2 = nn.BatchNorm2d(64)
        self.conv3 = nn.Conv2d(64, 128, 3, padding=1)
        self.bn3 = nn.BatchNorm2d(128)

        self.pool = nn.MaxPool2d(2)
        self.dropout = nn.Dropout(0.3)

        self.fc1 = nn.Linear(128 * 16 * 16, 256)  # assumes 256x256 inputs
        self.fc2 = nn.Linear(256, 1)

    def forward(self, x):
        # x: [B, 3, H, W] (e.g., 256x256)
        x = self.pool(F.relu(self.bn1(self.conv1(x))))
        x = self.pool(F.relu(self.bn2(self.conv2(x))))
        x = self.pool(F.relu(self.bn3(self.conv3(x))))  # [B, 128, H/8, W/8]

        x = torch.flatten(x, 1)
        x = self.dropout(F.relu(self.fc1(x)))
        logit = self.fc2(x)
        return logit  # anomaly logit

    @torch.no_grad()
    def anomaly_score(self, x) -> torch.Tensor:
        """
        Returns anomaly probability in [0,1].
        """
        self.eval()
        logit = self.forward(x)
        return torch.sigmoid(logit)
