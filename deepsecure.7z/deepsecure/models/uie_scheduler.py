# file: deepsecure/models/uie_scheduler.py

from dataclasses import dataclass
from typing import Dict, Any

import torch

from .uie_models import FunieGANStub, AURIEStub, CORALNetStub
from deepsecure.config import UIE_FUNIE, UIE_AURIE, UIE_CORAL, LOW_LIGHT_THRESHOLD


@dataclass
class SceneMetadata:
    avg_illumination: float
    device_type: str  # e.g. "edge", "auv_onboard", "shore"
    target_profile: str  # e.g. "shallow_reef", "scientific_imaging", "generic"


class UIEPipeline:
    """
    Implements:
    I_enh(x) = F_UIE(I_raw(x); θ)
    with adaptive model selection.
    """

    def __init__(self, device: str = "cuda"):
        self.device = device
        self.funie = FunieGANStub().to(device)
        self.aurie = AURIEStub().to(device)
        self.coral = CORALNetStub().to(device)

        self.models: Dict[str, torch.nn.Module] = {
            UIE_FUNIE: self.funie,
            UIE_AURIE: self.aurie,
            UIE_CORAL: self.coral,
        }

    def choose_model_name(self, meta: SceneMetadata) -> str:
        """
        Encodes logic:
            F_UIE = FUnIE-GAN,      if device_type = edge
                    AURIE,          if illumination_variation
                    CORAL-Net,      if target = shallow_reef
        """
        if meta.target_profile == "shallow_reef":
            return UIE_CORAL

        if meta.avg_illumination < LOW_LIGHT_THRESHOLD:
            return UIE_AURIE

        if meta.device_type == "edge":
            return UIE_FUNIE

        # default
        return UIE_AURIE

    def enhance(self, img: torch.Tensor, meta: SceneMetadata) -> torch.Tensor:
        """
        img: [B,3,H,W] normalized to [0,1]
        """
        model_name = self.choose_model_name(meta)
        model = self.models[model_name]
        return model.enhance(img)
